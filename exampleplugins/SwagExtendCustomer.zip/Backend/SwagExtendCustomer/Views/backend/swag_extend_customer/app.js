//{block name="backend/customer/application"}
// {$smarty.block.parent}
// {include file="backend/swag_extend_customer/view/detail/my_own_tab.js"}
//{/block}