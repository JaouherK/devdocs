//{block name="backend/risk_management/store/risk/data"}
// {$smarty.block.parent}
{ description: 'My Custom Rule', value: 'MyCustomRule' },
//{/block}
